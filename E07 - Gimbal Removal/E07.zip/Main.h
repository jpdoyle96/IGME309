/*----------------------------------------------
Programmer: Alberto Bobadilla (labigm@rit.edu)
Date: 2021/02
----------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_
#include "AppClass.h"

//Define and libraries to use memory allocation check
#define _CRTDBG_MAP_ALLOC
#include <cstdlib>
#include <crtdbg.h>

#endif //__MAIN_H_

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/